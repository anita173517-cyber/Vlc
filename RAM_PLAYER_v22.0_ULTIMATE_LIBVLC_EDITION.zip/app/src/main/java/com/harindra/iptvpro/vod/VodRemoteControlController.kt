package com.harindra.iptvpro.vod

import android.view.KeyEvent

/**
 * Pure Android TV Remote-Control Action Router for Dedicated VOD Playback.
 *
 * - Never triggers Live TV channel switching or accidental app exit.
 * - Cleanly separates hidden-controls shortcuts from visible-controls focus navigation.
 * - Supports D-pad Up/Down/Left/Right, OK/ENTER, Back, Play/Pause, Rewind, Fast-Forward, Menu.
 */
enum class VodRemoteAction {
    NONE,
    SHOW_CONTROLS_AND_FOCUS_PLAY,
    HIDE_CONTROLS,
    CLOSE_SIDE_PANEL,
    TOGGLE_PLAY_PAUSE,
    SEEK_REWIND_STEP,
    SEEK_FORWARD_STEP,
    SEEK_REWIND_CONTINUOUS,
    SEEK_FORWARD_CONTINUOUS,
    COMMIT_CONTINUOUS_SEEK,
    OPEN_SETTINGS_PANEL,
    EXIT_VOD_PLAYER,
    RESET_AUTO_HIDE_ONLY
}

class VodRemoteControlController {

    fun onKeyDown(
        keyCode: Int,
        repeatCount: Int,
        controlsVisible: Boolean,
        sidePanelOpen: Boolean,
        errorOverlayVisible: Boolean,
        autoNextVisible: Boolean,
        seekBarFocused: Boolean
    ): VodRemoteAction {
        if (errorOverlayVisible) {
            return if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                VodRemoteAction.EXIT_VOD_PLAYER
            } else {
                VodRemoteAction.NONE
            }
        }

        if (sidePanelOpen) {
            return if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                VodRemoteAction.CLOSE_SIDE_PANEL
            } else {
                VodRemoteAction.RESET_AUTO_HIDE_ONLY
            }
        }

        if (keyCode == KeyEvent.KEYCODE_MENU) {
            return VodRemoteAction.OPEN_SETTINGS_PANEL
        }

        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
            keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
            keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE ||
            keyCode == KeyEvent.KEYCODE_SPACE
        ) {
            return VodRemoteAction.TOGGLE_PLAY_PAUSE
        }

        if (keyCode == KeyEvent.KEYCODE_MEDIA_REWIND) {
            return if (repeatCount > 0) VodRemoteAction.SEEK_REWIND_CONTINUOUS else VodRemoteAction.SEEK_REWIND_STEP
        }

        if (keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) {
            return if (repeatCount > 0) VodRemoteAction.SEEK_FORWARD_CONTINUOUS else VodRemoteAction.SEEK_FORWARD_STEP
        }

        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            return when {
                controlsVisible -> VodRemoteAction.HIDE_CONTROLS
                else -> VodRemoteAction.EXIT_VOD_PLAYER
            }
        }

        if (!controlsVisible) {
            return when (keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    if (autoNextVisible) VodRemoteAction.NONE else VodRemoteAction.SHOW_CONTROLS_AND_FOCUS_PLAY
                }
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (autoNextVisible) VodRemoteAction.NONE else VodRemoteAction.SHOW_CONTROLS_AND_FOCUS_PLAY
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (repeatCount > 0) VodRemoteAction.SEEK_REWIND_CONTINUOUS else VodRemoteAction.SEEK_REWIND_STEP
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (repeatCount > 0) VodRemoteAction.SEEK_FORWARD_CONTINUOUS else VodRemoteAction.SEEK_FORWARD_STEP
                }
                else -> VodRemoteAction.NONE
            }
        }

        // Controls are visible: if SeekBar is focused, Left/Right scrubs smoothly via our seek engine
        if (seekBarFocused) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                return if (repeatCount > 0) VodRemoteAction.SEEK_REWIND_CONTINUOUS else VodRemoteAction.SEEK_REWIND_STEP
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                return if (repeatCount > 0) VodRemoteAction.SEEK_FORWARD_CONTINUOUS else VodRemoteAction.SEEK_FORWARD_STEP
            }
        }

        return VodRemoteAction.RESET_AUTO_HIDE_ONLY
    }

    fun onKeyUp(keyCode: Int, isContinuousScrubbing: Boolean): VodRemoteAction {
        if (!isContinuousScrubbing) return VodRemoteAction.NONE
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_MEDIA_REWIND,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> VodRemoteAction.COMMIT_CONTINUOUS_SEEK
            else -> VodRemoteAction.NONE
        }
    }
}
