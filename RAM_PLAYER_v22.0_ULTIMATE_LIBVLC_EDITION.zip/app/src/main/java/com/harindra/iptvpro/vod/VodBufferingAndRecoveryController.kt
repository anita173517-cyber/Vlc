package com.harindra.iptvpro.vod

/**
 * RAM PLAYER v22.0 — Intelligent VOD Buffering & Bounded Stream Recovery Controller.
 *
 * - Differentiates Initial Loading (clean minimal spinner over black) from Rebuffering
 *   (keeps video frame visible with subtle inline indicator).
 * - Automatic HW -> SW decoder fallback on first decode failure.
 * - Strictly bounded retry budget (max 3 retries, 0 for fatal 401/403/404/410) — never infinite loops.
 * - Never exposes credentials, tokens, or sensitive URLs in error messages.
 */
enum class VodRecoveryDecisionType {
    RETRY_WITH_BACKOFF,
    FALLBACK_SOFTWARE_DECODER,
    SHOW_FATAL_ERROR
}

data class VodRecoveryDecision(
    val type: VodRecoveryDecisionType,
    val delayMs: Long = 0L,
    val attemptNumber: Int = 0,
    val maxAttempts: Int = 3,
    val userTitle: String = "",
    val userMessage: String = "",
    val canManualRetry: Boolean = true
)

class VodBufferingAndRecoveryController(
    private val maxTransientRetries: Int = 3
) {
    private var retryCount: Int = 0
    private var triedSoftwareFallback: Boolean = false
    private var hasRenderedFirstFrame: Boolean = false

    fun resetForNewMedia() {
        retryCount = 0
        triedSoftwareFallback = false
        hasRenderedFirstFrame = false
    }

    fun markPlaybackStarted() {
        hasRenderedFirstFrame = true
        retryCount = 0
    }

    fun isInitialLoad(): Boolean = !hasRenderedFirstFrame

    fun currentRetryCount(): Int = retryCount

    fun hasTriedSoftwareFallback(): Boolean = triedSoftwareFallback

    fun evaluateError(
        rawMessage: String,
        currentDecoderMode: VodDecoderMode
    ): VodRecoveryDecision {
        val lower = rawMessage.lowercase()
        if (lower.contains("401") || lower.contains("403") || lower.contains("unauthorized")) {
            return VodRecoveryDecision(
                type = VodRecoveryDecisionType.SHOW_FATAL_ERROR,
                userTitle = "Authentication Error",
                userMessage = "Your Xtream session expired or this VOD stream is not authorized.",
                canManualRetry = false
            )
        }
        if (lower.contains("404") || lower.contains("410") || lower.contains("not found")) {
            return VodRecoveryDecision(
                type = VodRecoveryDecisionType.SHOW_FATAL_ERROR,
                userTitle = "Title Unavailable",
                userMessage = "This movie or episode is no longer available on the provider server.",
                canManualRetry = false
            )
        }

        // If hardware decoder failed before first frame, attempt clean Software (FFmpeg/avcodec) fallback once
        if (!hasRenderedFirstFrame && !triedSoftwareFallback && currentDecoderMode != VodDecoderMode.SOFTWARE_ONLY) {
            triedSoftwareFallback = true
            return VodRecoveryDecision(
                type = VodRecoveryDecisionType.FALLBACK_SOFTWARE_DECODER,
                delayMs = 400L,
                attemptNumber = retryCount,
                maxAttempts = maxTransientRetries,
                userTitle = "Switching to Software Decoder",
                userMessage = "Hardware decoder could not open this stream — switching to LibVLC Software Decoder."
            )
        }

        if (retryCount < maxTransientRetries) {
            retryCount++
            val backoff = when (retryCount) {
                1 -> 1_200L
                2 -> 2_500L
                else -> 4_000L
            }
            return VodRecoveryDecision(
                type = VodRecoveryDecisionType.RETRY_WITH_BACKOFF,
                delayMs = backoff,
                attemptNumber = retryCount,
                maxAttempts = maxTransientRetries,
                userTitle = "Reconnecting ($retryCount/$maxTransientRetries)",
                userMessage = "Network hiccup detected — preserving position and reconnecting..."
            )
        }

        return VodRecoveryDecision(
            type = VodRecoveryDecisionType.SHOW_FATAL_ERROR,
            attemptNumber = retryCount,
            maxAttempts = maxTransientRetries,
            userTitle = "Unable to Play Stream",
            userMessage = "The provider server did not respond cleanly after $maxTransientRetries attempts. You can retry or return to details.",
            canManualRetry = true
        )
    }
}
