package com.harindra.iptvpro

import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.util.Locale

/**
 * StreamX Media3 Pro v18.1 — Next-Generation Ultra Upgrade Modular Engine Hub (`SmartEngineHub.kt`).
 *
 * Implements Section 39 Modular Architecture Refactoring without breaking existing callers:
 * 1. [LiveTvBackgroundPlaybackController] — Stops Live TV audio/video & releases buffers immediately when
 *    entering Movies, Series, Search, Settings, or Home (unless PiP is active), remembers channel selection,
 *    and respects user auto-reconnect preferences on return.
 * 2. [SearchIntelligenceEngine] — Fast, zero-allocation-hot-loop, typo-tolerant & token-order-independent
 *    search across Live TV, Channel Numbers, Categories, Movies, Series, Episodes, and EPG.
 * 3. [PlaylistHealthEngine] — Analyzes Live/VOD/Series catalogs and identifies duplicate channel candidates
 *    by normalized name or stream URL without ever auto-deleting channels without user confirmation.
 * 4. [BackupRestoreEngine] — Versioned (`SXBK_V19`) backup & restore with explicit credential redaction option
 *    and strict schema validation.
 * 5. [DiagnosticsEngine] — Real measured playback & network diagnostics with credential redaction.
 * 6. [PersonalizationEngine] — Local, zero-cloud Home screen personalization based on real watch history.
 */
object LiveTvBackgroundPlaybackController {

    data class SuspendedLiveTvState(
        val wasSuspended: Boolean,
        val channelIndex: Int,
        val channelId: String,
        val channelName: String,
        val sectionEntered: String,
        val suspendedAtMs: Long
    )

    @Volatile
    private var currentSuspendedState = SuspendedLiveTvState(
        wasSuspended = false,
        channelIndex = 0,
        channelId = "",
        channelName = "",
        sectionEntered = "",
        suspendedAtMs = 0L
    )

    fun shouldSuspendLiveTvForSection(
        isLiveTvPlaybackMode: Boolean,
        isInPictureInPictureMode: Boolean,
        stopInBackgroundSettingEnabled: Boolean
    ): Boolean {
        if (isInPictureInPictureMode) return false
        if (!stopInBackgroundSettingEnabled) return false
        return isLiveTvPlaybackMode
    }

    fun recordLiveTvSuspended(
        channelIndex: Int,
        channelId: String,
        channelName: String,
        targetSectionName: String,
        nowMs: Long = System.currentTimeMillis()
    ): SuspendedLiveTvState {
        val state = SuspendedLiveTvState(
            wasSuspended = true,
            channelIndex = channelIndex.coerceAtLeast(0),
            channelId = channelId,
            channelName = channelName,
            sectionEntered = targetSectionName,
            suspendedAtMs = nowMs
        )
        currentSuspendedState = state
        return state
    }

    fun peekSuspendedState(): SuspendedLiveTvState = currentSuspendedState

    fun consumeSuspendedState(): SuspendedLiveTvState {
        val prev = currentSuspendedState
        currentSuspendedState = prev.copy(wasSuspended = false)
        return prev
    }

    fun clearSuspendedState() {
        currentSuspendedState = SuspendedLiveTvState(
            wasSuspended = false,
            channelIndex = 0,
            channelId = "",
            channelName = "",
            sectionEntered = "",
            suspendedAtMs = 0L
        )
    }
}

object SearchIntelligenceEngine {

    fun normalizeSearchText(raw: String): String {
        if (raw.isEmpty()) return ""
        val sb = StringBuilder(raw.length)
        var lastWasSpace = true
        for (i in 0 until raw.length) {
            val c = raw[i].lowercaseChar()
            if (c in 'a'..'z' || c in '0'..'9') {
                sb.append(c)
                lastWasSpace = false
            } else if (!lastWasSpace) {
                sb.append(' ')
                lastWasSpace = true
            }
        }
        return sb.toString().trim()
    }

    /**
     * Fast multi-token & 1-edit typo-tolerant matcher for TV remote search queries.
     */
    fun matchesSmartQuery(
        title: String,
        categoryOrSubtitle: String,
        rawQuery: String,
        channelNumberStr: String = ""
    ): Boolean {
        val qTrim = rawQuery.trim()
        if (qTrim.isEmpty()) return true
        if (channelNumberStr.isNotEmpty() && channelNumberStr == qTrim) return true
        if (title.contains(qTrim, ignoreCase = true) || categoryOrSubtitle.contains(qTrim, ignoreCase = true)) {
            return true
        }
        val normQuery = normalizeSearchText(qTrim)
        if (normQuery.isEmpty()) return true
        val normHaystack = normalizeSearchText("$title $categoryOrSubtitle $channelNumberStr")
        if (normHaystack.contains(normQuery)) return true

        val queryTokens = normQuery.split(' ').filter { it.isNotEmpty() }
        if (queryTokens.size > 1 && queryTokens.all { tok -> normHaystack.contains(tok) }) {
            return true
        }

        // Typo tolerance (Levenshtein distance <= 1) for single words >= 4 chars
        if (queryTokens.size == 1 && normQuery.length >= 4) {
            val haystackWords = normHaystack.split(' ')
            for (word in haystackWords) {
                if (word.length >= 4 && isWithinOneEditDistance(word, normQuery)) {
                    return true
                }
            }
        }
        return false
    }

    fun isWithinOneEditDistance(a: String, b: String): Boolean {
        val lenA = a.length
        val lenB = b.length
        if (kotlin.math.abs(lenA - lenB) > 1) return false
        var i = 0
        var j = 0
        var edits = 0
        while (i < lenA && j < lenB) {
            if (a[i] == b[j]) {
                i++
                j++
            } else {
                edits++
                if (edits > 1) return false
                when {
                    lenA > lenB -> i++
                    lenB > lenA -> j++
                    else -> {
                        i++
                        j++
                    }
                }
            }
        }
        if (i < lenA || j < lenB) edits++
        return edits <= 1
    }
}

object PlaylistHealthEngine {

    data class DuplicateChannelGroup(
        val normalizedName: String,
        val displayTitle: String,
        val category: String,
        val channelIndices: List<Int>,
        val channelIds: List<String>,
        val hasDistinctUrls: Boolean
    )

    data class PlaylistHealthReport(
        val totalLiveChannels: Int,
        val totalVodMovies: Int,
        val totalSeries: Int,
        val channelsWithBackupStream: Int,
        val channelsWithLogo: Int,
        val channelsMissingLogo: Int,
        val channelsWithEpgId: Int,
        val hiddenChannelsCount: Int,
        val duplicateGroups: List<DuplicateChannelGroup>
    )

    fun analyzeCatalogHealth(
        liveChannels: List<Channel>,
        vodMovies: List<Channel>,
        seriesGroups: List<SeriesGroupSummary>,
        hiddenChannelIds: Set<String> = emptySet()
    ): PlaylistHealthReport {
        var withBackup = 0
        var withLogo = 0
        var withEpg = 0
        val byNormName = LinkedHashMap<String, ArrayList<Int>>(liveChannels.size.coerceAtMost(4096))

        for (i in liveChannels.indices) {
            val ch = liveChannels[i]
            if (ch.backupUrl.isNotBlank()) withBackup++
            if (ch.logoUrl.isNotBlank()) withLogo++
            if (ch.epgId.isNotBlank()) withEpg++
            val normKey = SearchIntelligenceEngine.normalizeSearchText(ch.name)
            if (normKey.length >= 3) {
                byNormName.getOrPut(normKey) { ArrayList(2) }.add(i)
            }
        }

        val duplicates = ArrayList<DuplicateChannelGroup>()
        for ((normKey, indices) in byNormName) {
            if (indices.size > 1) {
                val firstCh = liveChannels[indices[0]]
                val urls = indices.map { liveChannels[it].streamUrl }.toSet()
                duplicates.add(
                    DuplicateChannelGroup(
                        normalizedName = normKey,
                        displayTitle = firstCh.name,
                        category = firstCh.category,
                        channelIndices = indices,
                        channelIds = indices.map { liveChannels[it].id },
                        hasDistinctUrls = urls.size > 1
                    )
                )
                if (duplicates.size >= 80) break
            }
        }

        return PlaylistHealthReport(
            totalLiveChannels = liveChannels.size,
            totalVodMovies = vodMovies.size,
            totalSeries = seriesGroups.size,
            channelsWithBackupStream = withBackup,
            channelsWithLogo = withLogo,
            channelsMissingLogo = (liveChannels.size - withLogo).coerceAtLeast(0),
            channelsWithEpgId = withEpg,
            hiddenChannelsCount = hiddenChannelIds.size,
            duplicateGroups = duplicates
        )
    }
}

object BackupRestoreEngine {
    const val BACKUP_FORMAT_VERSION = "SXBK_V19"
    const val BACKUP_FORMAT_V20 = "SXBK_V20"
    const val ENCRYPTED_BACKUP_PREFIX = "SXBK_ENC1:"

    fun encryptBackupWithPassword(plainJson: String, password: String): String {
        if (password.isBlank()) return plainJson
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(PBEKeySpec(password.toCharArray(), salt, 10_000, 256)).encoded
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
        val cipherBytes = cipher.doFinal(plainJson.toByteArray(Charsets.UTF_8))
        val combined = ByteArray(salt.size + iv.size + cipherBytes.size)
        System.arraycopy(salt, 0, combined, 0, salt.size)
        System.arraycopy(iv, 0, combined, salt.size, iv.size)
        System.arraycopy(cipherBytes, 0, combined, salt.size + iv.size, cipherBytes.size)
        return ENCRYPTED_BACKUP_PREFIX + combined.joinToString("") { "%02x".format(it) }
    }

    fun decryptBackupWithPassword(payload: String, password: String): String? {
        val trimmed = payload.trim()
        if (!trimmed.startsWith(ENCRYPTED_BACKUP_PREFIX)) return trimmed
        if (password.isBlank()) return null
        return try {
            val hex = trimmed.removePrefix(ENCRYPTED_BACKUP_PREFIX)
            if (hex.length % 2 != 0) return null
            val raw = ByteArray(hex.length / 2) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
            if (raw.size <= 28) return null
            val salt = raw.copyOfRange(0, 16)
            val iv = raw.copyOfRange(16, 28)
            val ct = raw.copyOfRange(28, raw.size)
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val keyBytes = factory.generateSecret(PBEKeySpec(password.toCharArray(), salt, 10_000, 256)).encoded
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    data class BackupValidationResult(
        val isValid: Boolean,
        val formatVersion: String,
        val profileCount: Int,
        val includesCredentials: Boolean,
        val favoriteCount: Int,
        val movieWatchlistCount: Int,
        val seriesWatchlistCount: Int,
        val customGroupCount: Int,
        val message: String
    )

    fun exportVersionedBackupJson(
        profileStore: ProfileStore,
        liveFavoriteIds: Set<String>,
        accountScope: String,
        includeCredentials: Boolean
    ): String {
        val root = JSONObject()
        root.put("formatVersion", BACKUP_FORMAT_VERSION)
        root.put("exportedAtMs", System.currentTimeMillis())
        root.put("includesCredentials", includeCredentials)
        root.put("accountScope", profileStore.normalizeScope(accountScope))

        val profilesArr = JSONArray()
        for (p in profileStore.all()) {
            profilesArr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("type", p.type.name)
                    .put("source", if (includeCredentials) p.source else NetworkClient.redactSensitiveUrl(p.source))
                    .put("username", if (includeCredentials) p.username else "")
                    .put("password", if (includeCredentials) p.password else "")
            )
        }
        root.put("profiles", profilesArr)

        val favArr = JSONArray()
        liveFavoriteIds.forEach { favArr.put(it) }
        root.put("liveFavorites", favArr)

        val movieWlArr = JSONArray()
        profileStore.getMovieWatchlistIds(accountScope).forEach { movieWlArr.put(it) }
        root.put("movieWatchlist", movieWlArr)

        val seriesWlArr = JSONArray()
        profileStore.getSeriesWatchlistIds(accountScope).forEach { seriesWlArr.put(it) }
        root.put("seriesWatchlist", seriesWlArr)

        val watchedArr = JSONArray()
        profileStore.getWatchedContentIds(accountScope).forEach { watchedArr.put(it) }
        root.put("watchedIds", watchedArr)

        val hiddenArr = JSONArray()
        profileStore.getHiddenChannelIds(accountScope).forEach { hiddenArr.put(it) }
        root.put("hiddenChannelIds", hiddenArr)

        val groupsObj = JSONObject()
        for ((gName, ids) in profileStore.getCustomChannelGroups(accountScope)) {
            val idArr = JSONArray()
            ids.forEach { idArr.put(it) }
            groupsObj.put(gName, idArr)
        }
        root.put("customChannelGroups", groupsObj)
        root.put("blacklistedChannels", JSONArray(profileStore.getBlacklistedChannelIds(accountScope).toList()))
        root.put("hiddenChannels", JSONArray(profileStore.getHiddenChannelIds(accountScope).toList()))
        root.put("watchedHistory", JSONArray(profileStore.getWatchedContentIds(accountScope).toList()))
        root.put("homeRowOrder", JSONArray(profileStore.getHomeRowOrder(accountScope)))
        root.put("hiddenHomeRows", JSONArray(profileStore.getHiddenHomeRows(accountScope).toList()))
        root.put("sidebarOrder", JSONArray(profileStore.getSidebarOrder(accountScope)))
        root.put("hiddenSidebarItems", JSONArray(profileStore.getHiddenSidebarItems(accountScope).toList()))
        val remoteObj = JSONObject()
        for (ck in listOf("RED", "GREEN", "YELLOW", "BLUE")) {
            remoteObj.put(ck, profileStore.getRemoteColorKeyAction(ck, accountScope))
        }
        root.put("remoteColorKeys", remoteObj)
        root.put("audioDelayMs", profileStore.getAudioDelayMs(accountScope))
        root.put("subtitleDelayMs", profileStore.getSubtitleDelayMs(accountScope))
        root.put("audioPassthrough", profileStore.isAudioPassthroughEnabled(accountScope))
        root.put("audioOffload", profileStore.isAudioOffloadEnabled(accountScope))
        root.put("autoRefreshHours", profileStore.getAutoRefreshIntervalHours(accountScope))
        root.put("autoRefreshOnStartup", profileStore.isAutoRefreshOnStartup(accountScope))
        root.put("osdTimeoutMs", profileStore.getOsdTimeoutMs())
        root.put("externalPlayerEnabled", profileStore.isExternalPlayerEnabled())

        val settingsObj = JSONObject()
            .put("autoNextEpisode", profileStore.isAutoNextEpisodeEnabled())
            .put("stopLiveTvInBg", profileStore.isStopLiveTvInBackgroundEnabled())
            .put("autoReconnectLiveOnReturn", profileStore.isAutoReconnectLiveTvOnReturnEnabled())
            .put("seekStepMs", profileStore.getSeekStepMs())
            .put("uiDensity", profileStore.getUiDensityMode().id)
            .put("overscanMarginDp", profileStore.getOverscanMarginDp())
            .put("clock24h", profileStore.is24HourClockEnabled())
            .put("highContrast", profileStore.isHighContrastTextEnabled())
        root.put("settings", settingsObj)

        return root.toString()
    }

    fun validateBackupJson(rawJson: String): BackupValidationResult {
        val trimmed = rawJson.trim()
        if (trimmed.isEmpty()) {
            return BackupValidationResult(false, "", 0, false, 0, 0, 0, 0, "Backup payload is empty")
        }
        return try {
            val obj = JSONObject(trimmed)
            val version = obj.optString("formatVersion", "")
            if (version != BACKUP_FORMAT_VERSION && version != BACKUP_FORMAT_V20) {
                return BackupValidationResult(
                    false,
                    version,
                    0,
                    false,
                    0,
                    0,
                    0,
                    0,
                    "Unsupported backup version '$version' (expected $BACKUP_FORMAT_VERSION)"
                )
            }
            val profilesCount = obj.optJSONArray("profiles")?.length() ?: 0
            val incCreds = obj.optBoolean("includesCredentials", false)
            val favCount = obj.optJSONArray("liveFavorites")?.length() ?: 0
            val mWlCount = obj.optJSONArray("movieWatchlist")?.length() ?: 0
            val sWlCount = obj.optJSONArray("seriesWatchlist")?.length() ?: 0
            val grpCount = obj.optJSONObject("customChannelGroups")?.length() ?: 0
            BackupValidationResult(
                isValid = true,
                formatVersion = version,
                profileCount = profilesCount,
                includesCredentials = incCreds,
                favoriteCount = favCount,
                movieWatchlistCount = mWlCount,
                seriesWatchlistCount = sWlCount,
                customGroupCount = grpCount,
                message = "Valid $BACKUP_FORMAT_VERSION backup ($profilesCount profiles, $favCount favorites, ${mWlCount + sWlCount} watchlist items)"
            )
        } catch (e: Exception) {
            BackupValidationResult(false, "", 0, false, 0, 0, 0, 0, "Invalid JSON format: ${e.message}")
        }
    }

    fun restoreValidatedBackup(
        rawJson: String,
        profileStore: ProfileStore,
        accountScope: String,
        outLiveFavorites: MutableSet<String>
    ): Boolean {
        val validation = validateBackupJson(rawJson)
        if (!validation.isValid) return false
        return try {
            val obj = JSONObject(rawJson.trim())
            val incCreds = obj.optBoolean("includesCredentials", false)
            if (incCreds) {
                val profArr = obj.optJSONArray("profiles")
                if (profArr != null) {
                    for (i in 0 until profArr.length()) {
                        val p = profArr.getJSONObject(i)
                        val src = p.optString("source", "")
                        if (src.isNotBlank() && !src.contains("****")) {
                            profileStore.save(
                                PlaylistProfile(
                                    id = p.optString("id").ifBlank { "restored_$i" },
                                    name = p.optString("name", "Restored Profile"),
                                    type = runCatching { ProfileType.valueOf(p.optString("type", "M3U")) }.getOrDefault(ProfileType.M3U),
                                    source = src,
                                    username = p.optString("username", ""),
                                    password = p.optString("password", "")
                                )
                            )
                        }
                    }
                }
            }

            obj.optJSONArray("liveFavorites")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val id = arr.optString(i)
                    if (id.isNotBlank()) outLiveFavorites.add(id)
                }
            }

            val currentMovieWl = profileStore.getMovieWatchlistIds(accountScope)
            obj.optJSONArray("movieWatchlist")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val id = arr.optString(i)
                    if (id.isNotBlank() && !currentMovieWl.contains(id)) {
                        profileStore.toggleMovieWatchlist(id, ContentSourceType.XTREAM_VOD_MOVIE, accountScope)
                    }
                }
            }

            val currentSeriesWl = profileStore.getSeriesWatchlistIds(accountScope)
            obj.optJSONArray("seriesWatchlist")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val id = arr.optString(i)
                    if (id.isNotBlank() && !currentSeriesWl.contains(id)) {
                        profileStore.toggleSeriesWatchlist(id, ContentSourceType.XTREAM_SERIES, accountScope)
                    }
                }
            }

            obj.optJSONArray("watchedIds")?.let { arr ->
                val list = ArrayList<String>(arr.length())
                for (i in 0 until arr.length()) {
                    val id = arr.optString(i)
                    if (id.isNotBlank()) list.add(id)
                }
                if (list.isNotEmpty()) profileStore.markSeasonWatched(list, accountScope)
            }

            obj.optJSONObject("customChannelGroups")?.let { gObj ->
                val keys = gObj.keys()
                while (keys.hasNext()) {
                    val gName = keys.next()
                    val idArr = gObj.optJSONArray(gName) ?: continue
                    for (i in 0 until idArr.length()) {
                        val chId = idArr.optString(i)
                        if (chId.isNotBlank()) {
                            profileStore.addChannelToCustomGroup(gName, chId, accountScope)
                        }
                    }
                }
            }

            obj.optJSONObject("settings")?.let { s ->
                if (s.has("autoNextEpisode")) profileStore.setAutoNextEpisodeEnabled(s.optBoolean("autoNextEpisode", true))
                if (s.has("stopLiveTvInBg")) profileStore.setStopLiveTvInBackgroundEnabled(s.optBoolean("stopLiveTvInBg", true))
                if (s.has("autoReconnectLiveOnReturn")) profileStore.setAutoReconnectLiveTvOnReturnEnabled(s.optBoolean("autoReconnectLiveOnReturn", false))
                if (s.has("seekStepMs")) profileStore.setSeekStepMs(s.optLong("seekStepMs", 15_000L))
                if (s.has("uiDensity")) profileStore.setUiDensityMode(UiDensityMode.fromId(s.optString("uiDensity")))
                if (s.has("overscanMarginDp")) profileStore.setOverscanMarginDp(s.optInt("overscanMarginDp", 0))
                if (s.has("clock24h")) profileStore.set24HourClockEnabled(s.optBoolean("clock24h", false))
                if (s.has("highContrast")) profileStore.setHighContrastTextEnabled(s.optBoolean("highContrast", false))
            }
            obj.optJSONArray("blacklistedChannels")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val id = arr.optString(i, "")
                    if (id.isNotBlank() && !profileStore.isChannelBlacklisted(id, accountScope)) {
                        profileStore.toggleChannelBlacklist(id, accountScope)
                    }
                }
            }
            obj.optJSONArray("homeRowOrder")?.let { arr ->
                val list = (0 until arr.length()).mapNotNull { arr.optString(it, "").takeIf { s -> s.isNotBlank() } }
                if (list.isNotEmpty()) profileStore.setHomeRowOrder(list, accountScope)
            }
            obj.optJSONArray("hiddenHomeRows")?.let { arr ->
                val set = (0 until arr.length()).mapNotNull { arr.optString(it, "").takeIf { s -> s.isNotBlank() } }.toSet()
                profileStore.setHiddenHomeRows(set, accountScope)
            }
            obj.optJSONArray("sidebarOrder")?.let { arr ->
                val list = (0 until arr.length()).mapNotNull { arr.optString(it, "").takeIf { s -> s.isNotBlank() } }
                if (list.isNotEmpty()) profileStore.setSidebarOrder(list, accountScope)
            }
            obj.optJSONArray("hiddenSidebarItems")?.let { arr ->
                val set = (0 until arr.length()).mapNotNull { arr.optString(it, "").takeIf { s -> s.isNotBlank() } }.toSet()
                profileStore.setHiddenSidebarItems(set, accountScope)
            }
            obj.optJSONObject("remoteColorKeys")?.let { rk ->
                for (ck in listOf("RED", "GREEN", "YELLOW", "BLUE")) {
                    val act = rk.optString(ck, "")
                    if (act.isNotBlank()) profileStore.setRemoteColorKeyAction(ck, act, accountScope)
                }
            }
            if (obj.has("audioDelayMs")) profileStore.setAudioDelayMs(obj.optInt("audioDelayMs", 0), accountScope)
            if (obj.has("subtitleDelayMs")) profileStore.setSubtitleDelayMs(obj.optInt("subtitleDelayMs", 0), accountScope)
            if (obj.has("audioPassthrough")) profileStore.setAudioPassthroughEnabled(obj.optBoolean("audioPassthrough", false), accountScope)
            if (obj.has("audioOffload")) profileStore.setAudioOffloadEnabled(obj.optBoolean("audioOffload", false), accountScope)
            if (obj.has("autoRefreshHours")) profileStore.setAutoRefreshIntervalHours(obj.optInt("autoRefreshHours", 0), accountScope)
            if (obj.has("autoRefreshOnStartup")) profileStore.setAutoRefreshOnStartup(obj.optBoolean("autoRefreshOnStartup", false), accountScope)
            if (obj.has("osdTimeoutMs")) profileStore.setOsdTimeoutMs(obj.optLong("osdTimeoutMs", 3500L))
            if (obj.has("externalPlayerEnabled")) profileStore.setExternalPlayerEnabled(obj.optBoolean("externalPlayerEnabled", false))
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Transactional Restore (v20.0): snapshots existing user state before applying any change,
     * validates schema & relationships, and rolls back completely if any failure occurs.
     */
    fun restoreValidatedBackupTransactional(
        rawJson: String,
        profileStore: ProfileStore,
        accountScope: String,
        outLiveFavorites: MutableSet<String>,
        simulateFailureForTest: Boolean = false
    ): Boolean {
        val check = validateBackupJson(rawJson)
        if (!check.isValid) return false

        // 1. Snapshot existing state prior to staging
        val prevFavs = HashSet(outLiveFavorites)
        val prevBlacklist = profileStore.getBlacklistedChannelIds(accountScope)
        val prevHomeOrder = profileStore.getHomeRowOrder(accountScope)
        val prevHomeHidden = profileStore.getHiddenHomeRows(accountScope)
        val prevSidebarOrder = profileStore.getSidebarOrder(accountScope)
        val prevSidebarHidden = profileStore.getHiddenSidebarItems(accountScope)
        val prevAudioDelay = profileStore.getAudioDelayMs(accountScope)
        val prevSubDelay = profileStore.getSubtitleDelayMs(accountScope)
        val prevAutoRefresh = profileStore.getAutoRefreshIntervalHours(accountScope)
        val prevAutoStartup = profileStore.isAutoRefreshOnStartup(accountScope)
        val prevOsdTimeout = profileStore.getOsdTimeoutMs()
        val prevExtPlayer = profileStore.isExternalPlayerEnabled()

        return try {
            val applied = restoreValidatedBackup(rawJson, profileStore, accountScope, outLiveFavorites)
            if (!applied || simulateFailureForTest) {
                throw IllegalStateException("Transactional restore verification failed")
            }
            true
        } catch (_: Exception) {
            // 2. Roll back atomically to pre-restore snapshot
            outLiveFavorites.clear()
            outLiveFavorites.addAll(prevFavs)
            profileStore.clearAllBlacklistedChannels(accountScope)
            prevBlacklist.forEach { profileStore.toggleChannelBlacklist(it, accountScope) }
            profileStore.setHomeRowOrder(prevHomeOrder, accountScope)
            profileStore.setHiddenHomeRows(prevHomeHidden, accountScope)
            profileStore.setSidebarOrder(prevSidebarOrder, accountScope)
            profileStore.setHiddenSidebarItems(prevSidebarHidden, accountScope)
            profileStore.setAudioDelayMs(prevAudioDelay, accountScope)
            profileStore.setSubtitleDelayMs(prevSubDelay, accountScope)
            profileStore.setAutoRefreshIntervalHours(prevAutoRefresh, accountScope)
            profileStore.setAutoRefreshOnStartup(prevAutoStartup, accountScope)
            profileStore.setOsdTimeoutMs(prevOsdTimeout)
            profileStore.setExternalPlayerEnabled(prevExtPlayer)
            false
        }
    }
}

object DiagnosticsEngine {

    fun buildRedactedDiagnosticExport(
        appVersion: String,
        performanceMode: PerformanceMode,
        uiDensityMode: UiDensityMode,
        usedHeapMb: Long,
        maxHeapMb: Long,
        liveCount: Int,
        vodCount: Int,
        seriesCount: Int,
        activeStreamUrl: String,
        videoDiagSummary: String,
        networkStatusSummary: String,
        lastErrorSummary: String,
        sxb2CacheKb: Long,
        epgCacheKb: Long
    ): String {
        val redactedUrl = NetworkClient.redactSensitiveUrl(activeStreamUrl).ifBlank { "None (Idle)" }
        return buildString {
            appendLine("=== StreamX Media3 Pro Diagnostic Export (Credentials Redacted) ===")
            appendLine("Version: $appVersion")
            appendLine("Performance Profile: ${performanceMode.title} (${performanceMode.id})")
            appendLine("UI Density Mode: ${uiDensityMode.title}")
            appendLine("JVM Heap Usage: ${usedHeapMb}MB / ${maxHeapMb}MB")
            appendLine("Separated Catalogs: $liveCount Live TV | $vodCount VOD Movies | $seriesCount Series")
            appendLine("Disk Cache: ${sxb2CacheKb}KB SXB2 | ${epgCacheKb}KB XMLTV EPG")
            appendLine("Active Stream (Redacted): $redactedUrl")
            appendLine("Measured Media3 Track Info: ${videoDiagSummary.ifBlank { "No active media track" }}")
            appendLine("Network State: $networkStatusSummary")
            appendLine("Recent Error Log: ${NetworkClient.redactSensitiveUrl(lastErrorSummary).ifBlank { "None" }}")
        }
    }
}

object PersonalizationEngine {

    data class HomeHeroRecommendation(
        val headline: String,
        val subtitle: String,
        val badgeText: String,
        val posterUrl: String,
        val contentType: ContentSourceType,
        val targetIndex: Int,
        val seriesSummary: SeriesGroupSummary? = null,
        val resumePositionMs: Long = 0L
    )

    fun selectCinematicHeroItem(
        continueWatching: List<PlaybackProgressEntry>,
        vodMovies: List<Channel>,
        vodIndexById: Map<String, Int>,
        seriesGroups: List<SeriesGroupSummary>,
        liveChannels: List<Channel>,
        currentChannelIndex: Int
    ): HomeHeroRecommendation {
        // 1. Prioritize most recent resumable Movie or Series Episode from Continue Watching
        val latestResume = continueWatching.firstOrNull()
        if (latestResume != null) {
            if (latestResume.contentType == ContentSourceType.XTREAM_VOD_MOVIE) {
                val mIdx = vodIndexById[latestResume.contentId]
                val movie = if (mIdx != null) vodMovies.getOrNull(mIdx) else null
                if (movie != null && mIdx != null) {
                    return HomeHeroRecommendation(
                        headline = movie.cleanMovieDisplayTitle(),
                        subtitle = "Continue Watching (${latestResume.progressPercent()}%) • ${movie.category}${movie.extractReleaseYear().let { if (it.isNotBlank()) " • $it" else "" }}",
                        badgeText = "RESUME ${latestResume.progressPercent()}%",
                        posterUrl = movie.logoUrl,
                        contentType = ContentSourceType.XTREAM_VOD_MOVIE,
                        targetIndex = mIdx,
                        resumePositionMs = latestResume.positionMs
                    )
                }
            } else if (latestResume.contentType == ContentSourceType.XTREAM_SERIES_EPISODE) {
                val grp = seriesGroups.firstOrNull { it.seriesKey == latestResume.seriesKey }
                if (grp != null) {
                    return HomeHeroRecommendation(
                        headline = grp.title,
                        subtitle = "Continue S${latestResume.seasonNumber}E${latestResume.episodeNumber} (${latestResume.progressPercent()}%) • ${grp.category}",
                        badgeText = "RESUME SERIES",
                        posterUrl = grp.posterUrl,
                        contentType = ContentSourceType.XTREAM_SERIES,
                        targetIndex = -1,
                        seriesSummary = grp,
                        resumePositionMs = latestResume.positionMs
                    )
                }
            }
        }

        // 2. Fallback to latest added VOD Movie if available
        val newestMovieIdx = vodMovies.indices.maxByOrNull { vodMovies[it].addedTimestamp }
        if (newestMovieIdx != null) {
            val m = vodMovies[newestMovieIdx]
            return HomeHeroRecommendation(
                headline = m.cleanMovieDisplayTitle(),
                subtitle = "Featured VOD Movie • ${m.category}${m.extractReleaseYear().let { if (it.isNotBlank()) " • $it" else "" }}",
                badgeText = "FEATURED MOVIE",
                posterUrl = m.logoUrl,
                contentType = ContentSourceType.XTREAM_VOD_MOVIE,
                targetIndex = newestMovieIdx
            )
        }

        // 3. Fallback to active/selected Live TV channel
        val liveIdx = currentChannelIndex.coerceIn(0, (liveChannels.size - 1).coerceAtLeast(0))
        val ch = liveChannels.getOrNull(liveIdx)
        return HomeHeroRecommendation(
            headline = ch?.name ?: "StreamX Live Television",
            subtitle = if (ch != null) "Channel ${ch.displayNumberFormatted()} • ${ch.category} • Ready to Watch" else "Connect your M3U or Xtream account",
            badgeText = "LIVE TV",
            posterUrl = ch?.logoUrl.orEmpty(),
            contentType = ch?.sourceType ?: ContentSourceType.M3U_LIVE,
            targetIndex = liveIdx
        )
    }
}


/**
 * RAM PLAYER v21.0 — Intelligent Audio Track Detection, Capability Selection & Bounded Recovery Engine.
 *
 * Prioritizes:
 * 1. User's per-channel / preferred language (only if supported)
 * 2. Hindi (`hi`, `hin`) supported track
 * 3. English (`en`, `eng`) supported track
 * 4. Any other valid supported track (preferring stereo/AAC/higher channel reliability)
 * NEVER selects an unsupported or nonexistent track.
 */
object AudioTrackIntelligenceEngine {

    private fun isHindi(lang: String): Boolean {
        val l = lang.trim().lowercase(Locale.ROOT)
        return l == "hi" || l == "hin" || l.startsWith("hi-") || l.contains("hindi")
    }

    private fun isEnglish(lang: String): Boolean {
        val l = lang.trim().lowercase(Locale.ROOT)
        return l == "en" || l == "eng" || l.startsWith("en-") || l.contains("english")
    }

    private fun matchesLang(track: AudioTrackDescriptor, target: String?): Boolean {
        if (target.isNullOrBlank()) return false
        val t = target.trim().lowercase(Locale.ROOT)
        val l = track.language.trim().lowercase(Locale.ROOT)
        val lbl = track.label.trim().lowercase(Locale.ROOT)
        if (l == t || l.startsWith("$t-")) return true
        if (isHindi(t) && (isHindi(l) || lbl.contains("hindi"))) return true
        if (isEnglish(t) && (isEnglish(l) || lbl.contains("english"))) return true
        return false
    }

    private fun codecPreferenceScore(track: AudioTrackDescriptor): Int {
        val m = track.mimeType.lowercase(Locale.ROOT)
        return when {
            m.contains("mp4a") || m.contains("aac") -> 50
            m.contains("mpeg") || m.contains("mp3") -> 45
            m.contains("opus") || m.contains("vorbis") -> 42
            m.contains("flac") || m.contains("raw") || m.contains("pcm") -> 40
            m.contains("eac3") -> 35
            m.contains("ac3") -> 30
            else -> 20
        }
    }

    fun selectBestAudioTrack(
        tracks: List<AudioTrackDescriptor>,
        preferredLanguage: String? = null
    ): AudioTrackDescriptor? {
        val supported = tracks.filter { it.isSupported }
        if (supported.isEmpty()) return null

        // 1. Explicit user-preferred language
        if (!preferredLanguage.isNullOrBlank()) {
            val prefMatches = supported.filter { matchesLang(it, preferredLanguage) }
            if (prefMatches.isNotEmpty()) {
                return prefMatches.maxByOrNull { codecPreferenceScore(it) }
            }
        }
        // 2. Hindi priority
        val hindiMatches = supported.filter { isHindi(it.language) || it.label.contains("hindi", ignoreCase = true) }
        if (hindiMatches.isNotEmpty()) {
            return hindiMatches.maxByOrNull { codecPreferenceScore(it) }
        }
        // 3. English priority
        val englishMatches = supported.filter { isEnglish(it.language) || it.label.contains("english", ignoreCase = true) }
        if (englishMatches.isNotEmpty()) {
            return englishMatches.maxByOrNull { codecPreferenceScore(it) }
        }
        // 4. Any other valid supported track
        return supported.maxByOrNull { codecPreferenceScore(it) }
    }

    fun findAlternativeSupportedTrack(
        tracks: List<AudioTrackDescriptor>,
        currentlySelected: AudioTrackDescriptor?
    ): AudioTrackDescriptor? {
        val supported = tracks.filter { it.isSupported }
        if (supported.size <= 1) return null
        val alternatives = supported.filterNot {
            currentlySelected != null &&
                it.groupIndex == currentlySelected.groupIndex &&
                it.trackIndex == currentlySelected.trackIndex
        }
        return alternatives.maxByOrNull { codecPreferenceScore(it) }
    }

    fun diagnoseAudioState(
        tracks: List<AudioTrackDescriptor>,
        decoderError: String? = null,
        outputError: String? = null,
        providerError: String? = null,
        outputCapability: String = "PCM Stereo",
        recoveryStatus: String = "Idle"
    ): AudioDiagnosticsSnapshot {
        val supportedCount = tracks.count { it.isSupported }
        val selected = tracks.firstOrNull { it.isSelected && it.isSupported }
            ?: tracks.firstOrNull { it.isSelected }

        val reason = when {
            !outputError.isNullOrBlank() -> AudioFailureReason.OUTPUT_ROUTING_ERROR
            !decoderError.isNullOrBlank() -> AudioFailureReason.DECODER_INIT_FAILED
            !providerError.isNullOrBlank() -> AudioFailureReason.PROVIDER_STREAM_ERROR
            tracks.isEmpty() -> AudioFailureReason.SOURCE_NO_AUDIO
            supportedCount == 0 -> AudioFailureReason.UNSUPPORTED_CODEC
            selected == null || !selected.isSupported -> AudioFailureReason.TRACK_UNSELECTED
            else -> AudioFailureReason.NONE
        }

        val decStatus = when (reason) {
            AudioFailureReason.NONE -> "Active (${selected?.shortCodecName() ?: "PCM"})"
            AudioFailureReason.DECODER_INIT_FAILED -> "Init Failed: ${decoderError?.take(60) ?: "Codec error"}"
            AudioFailureReason.OUTPUT_ROUTING_ERROR -> "Output Error: ${outputError?.take(60) ?: "AudioTrack"}"
            AudioFailureReason.UNSUPPORTED_CODEC -> "Unsupported (${tracks.firstOrNull()?.shortCodecName() ?: "Unknown"})"
            AudioFailureReason.SOURCE_NO_AUDIO -> "No Audio Track in Stream"
            AudioFailureReason.TRACK_UNSELECTED -> "Track Unselected — Recovery Needed"
            AudioFailureReason.PROVIDER_STREAM_ERROR -> "Provider Stream Issue"
        }

        return AudioDiagnosticsSnapshot(
            audioDetected = tracks.isNotEmpty(),
            totalTracks = tracks.size,
            supportedTracks = supportedCount,
            selectedTrack = selected,
            allTracks = tracks,
            decoderStatus = decStatus,
            outputCapability = outputCapability,
            recoveryStatus = recoveryStatus,
            failureReason = reason
        )
    }

    fun shouldAttemptAudioRecovery(
        snapshot: AudioDiagnosticsSnapshot,
        attemptsForChannel: Int,
        lastAttemptElapsedMs: Long,
        nowElapsedMs: Long,
        maxAttempts: Int = 2,
        cooldownMs: Long = 3500L
    ): Boolean {
        if (snapshot.failureReason == AudioFailureReason.NONE) return false
        if (snapshot.failureReason == AudioFailureReason.SOURCE_NO_AUDIO && attemptsForChannel >= 1) return false
        if (attemptsForChannel >= maxAttempts) return false
        if (lastAttemptElapsedMs > 0L && (nowElapsedMs - lastAttemptElapsedMs) < cooldownMs) return false
        return true
    }
}

/**
 * RAM PLAYER v21.0 — Universal Channel Playback Failure Classifier & Bounded Recovery Policy.
 * Never marks every failed stream as a generic network error.
 */
object PlaybackRecoveryEngine {

    fun classifyFailure(
        errorCode: Int,
        errorCodeName: String,
        message: String?,
        httpStatusCode: Int = 0
    ): PlaybackFailureCategory {
        val msg = message?.lowercase(Locale.ROOT).orEmpty()
        val codeName = errorCodeName.uppercase(Locale.ROOT)

        return when {
            codeName.contains("BEHIND_LIVE_WINDOW") -> PlaybackFailureCategory.LIVE_WINDOW_DRIFT
            httpStatusCode == 401 || httpStatusCode == 403 || msg.contains("response code: 401") || msg.contains("response code: 403") ->
                PlaybackFailureCategory.PROVIDER_AUTH_ERROR
            httpStatusCode == 404 || httpStatusCode == 410 || msg.contains("response code: 404") || msg.contains("response code: 410") ->
                if (msg.contains(".ts") || msg.contains(".m4s") || msg.contains("segment")) {
                    PlaybackFailureCategory.MISSING_SEGMENT
                } else {
                    PlaybackFailureCategory.HTTP_NOT_FOUND
                }
            httpStatusCode == 429 || msg.contains("response code: 429") -> PlaybackFailureCategory.HTTP_RATE_LIMITED
            httpStatusCode in 500..599 || msg.contains("response code: 50") -> PlaybackFailureCategory.HTTP_SERVER_ERROR
            codeName.contains("IO_BAD_HTTP_STATUS") -> PlaybackFailureCategory.HTTP_ERROR
            codeName.contains("IO_NETWORK_CONNECTION_TIMEOUT") || msg.contains("timed out") || msg.contains("timeout") ->
                PlaybackFailureCategory.CONNECTION_TIMEOUT
            msg.contains("unknownhost") || msg.contains("unable to resolve host") || msg.contains("dns") ->
                PlaybackFailureCategory.DNS_ERROR
            codeName.contains("PARSING_MANIFEST") || msg.contains("extm3u") || msg.contains("playlist") ->
                PlaybackFailureCategory.HLS_MANIFEST_ERROR
            codeName.contains("DECODER_INIT_FAILED") -> PlaybackFailureCategory.DECODER_INIT_FAILED
            codeName.contains("DECODING_FORMAT_UNSUPPORTED") || msg.contains("unsupported") && msg.contains("codec") ->
                PlaybackFailureCategory.UNSUPPORTED_CODEC
            codeName.contains("IO_NETWORK_CONNECTION_FAILED") -> PlaybackFailureCategory.NETWORK_ERROR
            else -> PlaybackFailureCategory.UNKNOWN
        }
    }

    fun computeBackoffMs(attempt: Int, category: PlaybackFailureCategory): Long {
        val base = when (category) {
            PlaybackFailureCategory.LIVE_WINDOW_DRIFT -> 0L
            PlaybackFailureCategory.HTTP_RATE_LIMITED -> 2200L
            PlaybackFailureCategory.HTTP_SERVER_ERROR -> 1500L
            PlaybackFailureCategory.CONNECTION_TIMEOUT, PlaybackFailureCategory.DNS_ERROR -> 1200L
            else -> 900L
        }
        return (base * (1 shl (attempt - 1).coerceAtLeast(0))).coerceAtMost(4500L)
    }
}

/**
 * RAM PLAYER v21.0 — Monotonic 5-Second OK/ENTER Hold-to-Delete State Machine (Part 8).
 *
 * Guarantees:
 * - Uses monotonic elapsed time (`SystemClock.elapsedRealtime()` passed in by caller for testability).
 * - Supports `KEYCODE_DPAD_CENTER`, `KEYCODE_ENTER`, `KEYCODE_NUMPAD_ENTER`.
 * - Ignores repeat events so multiple confirmations or deletions can NEVER fire.
 * - Cancels cleanly if released before 5 full seconds, if focus is lost, or if any dialog/overlay opens.
 * - Separates short tap (<600ms), configurable short Long-Press OK (600ms..1600ms),
 *   and 5-second Delete Current Channel hold (5000ms).
 * - NEVER deletes automatically — always requests explicit user confirmation.
 */
class OkLongHoldDeleteController(
    val thresholdMs: Long = HOLD_CONFIRM_THRESHOLD_MS
) {
    companion object {
        const val HOLD_CONFIRM_THRESHOLD_MS = 5_000L
        const val OVERLAY_SHOW_DELAY_MS = 850L
        const val SHORT_LONG_PRESS_MIN_MS = 600L
        const val SHORT_LONG_PRESS_MAX_MS = 1_650L
    }

    enum class ReleaseOutcome {
        IGNORED,
        SHORT_TAP,
        CONFIGURABLE_LONG_PRESS,
        CANCELLED_EARLY,
        ALREADY_TRIGGERED
    }

    data class HoldProgress(
        val isActive: Boolean,
        val showCountdownOverlay: Boolean,
        val elapsedMs: Long,
        val remainingSeconds: Int,
        val progressPercent: Int,
        val justReachedThreshold: Boolean,
        val channelId: String,
        val channelName: String,
        val channelNumber: Int
    )

    private var activeKeyCode: Int = -1
    private var holdStartElapsedMs: Long = 0L
    private var triggeredForCurrentHold: Boolean = false
    private var targetChannelId: String = ""
    private var targetChannelName: String = ""
    private var targetChannelNumber: Int = 0

    fun isOkKeyCode(keyCode: Int): Boolean {
        // Android KeyEvent constants: DPAD_CENTER=23, ENTER=66, NUMPAD_ENTER=160
        return keyCode == 23 || keyCode == 66 || keyCode == 160
    }

    fun isHolding(): Boolean = activeKeyCode != -1

    fun onKeyDown(
        keyCode: Int,
        repeatCount: Int,
        nowElapsedMs: Long,
        isEligibleLiveTv: Boolean,
        channelId: String,
        channelName: String,
        channelNumber: Int
    ): Boolean {
        if (!isOkKeyCode(keyCode)) return false
        if (!isEligibleLiveTv || channelId.isBlank()) {
            cancel()
            return false
        }
        // Repeat events while already holding MUST NOT restart timer or re-trigger deletion
        if (repeatCount > 0) {
            return activeKeyCode == keyCode
        }
        activeKeyCode = keyCode
        holdStartElapsedMs = nowElapsedMs
        triggeredForCurrentHold = false
        targetChannelId = channelId
        targetChannelName = channelName
        targetChannelNumber = channelNumber
        return true
    }

    fun pollProgress(nowElapsedMs: Long): HoldProgress {
        if (activeKeyCode == -1) {
            return HoldProgress(false, false, 0L, 5, 0, false, "", "", 0)
        }
        val elapsed = (nowElapsedMs - holdStartElapsedMs).coerceAtLeast(0L)
        val remainingMs = (thresholdMs - elapsed).coerceAtLeast(0L)
        val remainingSec = ((remainingMs + 999L) / 1000L).toInt().coerceIn(0, 5)
        val pct = ((elapsed * 100L) / thresholdMs).toInt().coerceIn(0, 100)
        val showOverlay = elapsed >= OVERLAY_SHOW_DELAY_MS && !triggeredForCurrentHold
        val justTriggered = if (elapsed >= thresholdMs && !triggeredForCurrentHold) {
            triggeredForCurrentHold = true
            true
        } else {
            false
        }
        return HoldProgress(
            isActive = true,
            showCountdownOverlay = showOverlay,
            elapsedMs = elapsed,
            remainingSeconds = remainingSec,
            progressPercent = pct,
            justReachedThreshold = justTriggered,
            channelId = targetChannelId,
            channelName = targetChannelName,
            channelNumber = targetChannelNumber
        )
    }

    fun onKeyUp(keyCode: Int, nowElapsedMs: Long): ReleaseOutcome {
        if (activeKeyCode == -1 || keyCode != activeKeyCode) {
            return ReleaseOutcome.IGNORED
        }
        val elapsed = (nowElapsedMs - holdStartElapsedMs).coerceAtLeast(0L)
        val wasTriggered = triggeredForCurrentHold
        cancel()
        return when {
            wasTriggered -> ReleaseOutcome.ALREADY_TRIGGERED
            elapsed < SHORT_LONG_PRESS_MIN_MS -> ReleaseOutcome.SHORT_TAP
            elapsed <= SHORT_LONG_PRESS_MAX_MS -> ReleaseOutcome.CONFIGURABLE_LONG_PRESS
            else -> ReleaseOutcome.CANCELLED_EARLY
        }
    }

    fun cancel() {
        activeKeyCode = -1
        holdStartElapsedMs = 0L
        triggeredForCurrentHold = false
        targetChannelId = ""
        targetChannelName = ""
        targetChannelNumber = 0
    }
}

/**
 * RAM PLAYER v21.0 — Persistent Soft-Delete Filter for Categories & Individual Channels.
 * Keeps deleted categories and deleted channels separate from Hide, Favorite, Blacklist, and Custom Groups,
 * without ever modifying the remote playlist.
 */
object ChannelDeletionFilter {

    fun filterActiveChannels(
        rawChannels: List<Channel>,
        deletedCategories: Set<String>,
        deletedChannelKeys: Set<String>,
        deletedChannelIds: Set<String> = emptySet()
    ): List<Channel> {
        if (deletedCategories.isEmpty() && deletedChannelKeys.isEmpty() && deletedChannelIds.isEmpty()) {
            return rawChannels
        }
        val normDeletedCats = deletedCategories.map { it.trim().lowercase(Locale.ROOT) }.toHashSet()
        val out = ArrayList<Channel>(rawChannels.size)
        for (ch in rawChannels) {
            if (normDeletedCats.contains(ch.category.trim().lowercase(Locale.ROOT))) continue
            if (deletedChannelIds.contains(ch.id)) continue
            if (deletedChannelKeys.contains(ch.deletionKey())) continue
            out.add(ch)
        }
        return out
    }

    fun countChannelsByCategory(rawChannels: List<Channel>): Map<String, Int> {
        val counts = LinkedHashMap<String, Int>(64)
        for (ch in rawChannels) {
            val cat = ch.category.ifBlank { "Live TV" }
            counts[cat] = (counts[cat] ?: 0) + 1
        }
        return counts
    }

    fun mergeExcludedCategories(
        softDeleted: Set<String>,
        permanentlyDeleted: Set<String>
    ): Set<String> {
        if (softDeleted.isEmpty() && permanentlyDeleted.isEmpty()) return emptySet()
        val merged = HashSet<String>(softDeleted.size + permanentlyDeleted.size)
        merged.addAll(softDeleted)
        merged.addAll(permanentlyDeleted)
        return merged
    }

    fun collectActiveCategoriesWithCounts(
        liveChannels: List<Channel>,
        movieChannels: List<Channel> = emptyList(),
        seriesChannels: List<Channel> = emptyList(),
        excludedCategories: Set<String> = emptySet()
    ): List<Pair<String, Int>> {
        val normExcluded = excludedCategories.map { it.trim().lowercase(Locale.ROOT) }.toHashSet()
        val displayByLower = LinkedHashMap<String, String>(64)
        val countByLower = LinkedHashMap<String, Int>(64)

        fun ingest(list: List<Channel>, fallback: String) {
            for (ch in list) {
                val cat = ch.category.trim().ifBlank { fallback }
                val lower = cat.lowercase(Locale.ROOT)
                if (lower in normExcluded) continue
                if (!displayByLower.containsKey(lower)) {
                    displayByLower[lower] = cat
                }
                countByLower[lower] = (countByLower[lower] ?: 0) + 1
            }
        }

        ingest(liveChannels, "Live TV")
        ingest(movieChannels, "Movies")
        ingest(seriesChannels, "Series")

        return displayByLower.entries
            .map { (lower, display) -> display to (countByLower[lower] ?: 0) }
            .sortedBy { it.first.lowercase(Locale.ROOT) }
    }
}
