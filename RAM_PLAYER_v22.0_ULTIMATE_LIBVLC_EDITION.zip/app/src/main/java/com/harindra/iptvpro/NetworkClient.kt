package com.harindra.iptvpro

import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dispatcher
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Protocol
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.PushbackInputStream
import java.net.InetAddress
import java.util.zip.GZIPInputStream
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * RAM PLAYER v21.0 EXTREME MASTER EDITION — Scoped Network & Header Engine:
 *
 * CRITICAL v21.0 HEADER SCOPING FIX:
 * - Eliminates the v20.0 host-wide header leak (`hostStreamHeaders[host]`) where Channel A's
 *   custom headers accidentally leaked onto Channel B on the same provider host.
 * - Implements 4-tier scoped header resolution:
 *   1. Exact stream URL match (`customStreamHeaders[url]`)
 *   2. Exact URL without query token (`baseNoQueryHeaders[baseNoQuery]`)
 *   3. Scoped channel directory path-prefix match (`pathPrefixHeaders[origin + dirPath]`) for HLS
 *      variant playlists, init segments, and `.ts`/`.m4s` media segments belonging to that channel
 *      (never matches bare root `/` so unrelated channels on the same host stay isolated)
 *   4. Explicit redirect-chain mapping (`redirectStreamHeaders[targetUrl]`) with cross-host
 *      credential protection (never leaks `Authorization` or `Cookie` to unrelated hosts).
 */
object NetworkClient {
    const val DEFAULT_USER_AGENT = "RAMPlayer/21.0-AMOLED (AndroidTV)"
    const val USER_AGENT_PROFILE_AUTO = "AUTO"
    private const val MAX_WINNING_UA_HOSTS = 64
    private const val DNS_TTL_MS = 30L * 60L * 1000L // 30-minute TTL

    data class UserAgentPreset(
        val id: String,
        val label: String,
        val userAgent: String
    )

    val USER_AGENT_PRESETS: List<UserAgentPreset> = listOf(
        UserAgentPreset("OTT_NAVIGATOR", "OTT Navigator", "OTTNavigator/1.7.1.4 (Linux; Android 11; Android TV)"),
        UserAgentPreset("IPTV_SMARTERS", "IPTV Smarters Pro", "IPTVSmartersPro/4.0.3 (Linux; Android 11; TV)"),
        UserAgentPreset("TIVIMATE", "TiviMate", "TiviMate/5.1.0 (Android 11; TV)"),
        UserAgentPreset("VLC", "VLC (LibVLC)", "VLC/3.0.20 LibVLC/3.0.20"),
        UserAgentPreset("LAVF_KODI", "Kodi / Lavf", "Lavf/60.16.100"),
        UserAgentPreset("EXOPLAYER", "ExoPlayer / Media3", "ExoPlayerLib/2.19.1 (Linux;Android 11) AndroidXMedia3/1.4.1"),
        UserAgentPreset("CHROME_TV", "Chrome Android TV", "Mozilla/5.0 (Linux; Android 11; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"),
        UserAgentPreset("DALVIK", "Dalvik Android", "Dalvik/2.1.0 (Linux; U; Android 11; Android TV Build/R)")
    )

    @Volatile
    private var preferredUserAgentProfile: String = USER_AGENT_PROFILE_AUTO
    private val winningUserAgentByHost = ConcurrentHashMap<String, String>(64)

    fun setPreferredUserAgentProfile(profileId: String?) {
        val clean = profileId?.trim()?.uppercase(Locale.ROOT).orEmpty()
        val valid = clean == USER_AGENT_PROFILE_AUTO || USER_AGENT_PRESETS.any { it.id == clean }
        preferredUserAgentProfile = if (valid) clean else USER_AGENT_PROFILE_AUTO
        winningUserAgentByHost.clear()
    }

    fun getPreferredUserAgentProfile(): String = preferredUserAgentProfile

    fun getPreferredUserAgentLabel(): String {
        val id = preferredUserAgentProfile
        if (id == USER_AGENT_PROFILE_AUTO) return "Auto (8-Player Fallback)"
        return USER_AGENT_PRESETS.firstOrNull { it.id == id }?.label ?: "Auto (8-Player Fallback)"
    }

    fun isUserAgentFallbackHttpCode(code: Int): Boolean {
        return code == 401 || code == 403 || code == 405 || code == 406 ||
            code == 412 || code == 429 || code == 451 || code == 503
    }

    fun recordWinningUserAgent(host: String?, userAgent: String) {
        val h = host?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if (h.isEmpty() || userAgent.isBlank()) return
        if (winningUserAgentByHost.size >= MAX_WINNING_UA_HOSTS && !winningUserAgentByHost.containsKey(h)) {
            val oldest = winningUserAgentByHost.keys.firstOrNull()
            if (oldest != null) winningUserAgentByHost.remove(oldest)
        }
        winningUserAgentByHost[h] = userAgent
    }

    fun clearWinningUserAgents() {
        winningUserAgentByHost.clear()
    }

    fun resolveEffectiveUserAgent(host: String?): String {
        val profile = preferredUserAgentProfile
        if (profile != USER_AGENT_PROFILE_AUTO) {
            return USER_AGENT_PRESETS.firstOrNull { it.id == profile }?.userAgent
                ?: USER_AGENT_PRESETS.first().userAgent
        }
        val h = host?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if (h.isNotEmpty()) {
            winningUserAgentByHost[h]?.let { return it }
        }
        return USER_AGENT_PRESETS.first().userAgent
    }

    fun buildUserAgentFallbackChain(host: String?): List<String> {
        val profile = preferredUserAgentProfile
        if (profile != USER_AGENT_PROFILE_AUTO) {
            val forced = USER_AGENT_PRESETS.firstOrNull { it.id == profile }?.userAgent
                ?: USER_AGENT_PRESETS.first().userAgent
            return listOf(forced)
        }
        val chain = ArrayList<String>(USER_AGENT_PRESETS.size + 1)
        val h = host?.trim()?.lowercase(Locale.ROOT).orEmpty()
        val cached = if (h.isNotEmpty()) winningUserAgentByHost[h] else null
        if (!cached.isNullOrBlank()) {
            chain.add(cached)
        }
        for (preset in USER_AGENT_PRESETS) {
            if (preset.userAgent != cached) {
                chain.add(preset.userAgent)
            }
        }
        return chain
    }
    private const val MAX_DNS_ENTRIES = 64
    private const val MAX_HEADER_ENTRIES = 12_000
    private const val MAX_DRM_ENTRIES = 12_000
    private const val MAX_REDIRECT_ENTRIES = 1_024
    private const val MAX_COOKIE_HOSTS = 128

    data class StreamDrmConfig(
        val licenseType: String = "",
        val licenseKey: String = "",
        val manifestType: String = ""
    ) {
        fun hasDrm(): Boolean = licenseType.isNotBlank() && licenseKey.isNotBlank()
        fun isEmpty(): Boolean = licenseType.isBlank() && licenseKey.isBlank() && manifestType.isBlank()
    }

    private data class DnsEntry(
        val addresses: List<InetAddress>,
        val timestampMs: Long
    )

    private val dnsCache = ConcurrentHashMap<String, DnsEntry>(64)
    private val customStreamHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val baseNoQueryHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val pathPrefixHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val redirectStreamHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val streamDrmConfigs = ConcurrentHashMap<String, StreamDrmConfig>(64)
    private val baseNoQueryDrmConfigs = ConcurrentHashMap<String, StreamDrmConfig>(64)
    private val sessionCookiesByHost = ConcurrentHashMap<String, List<Cookie>>(32)

    private val BLOCKED_HOP_HEADERS = setOf(
        "host",
        "content-length",
        "connection",
        "transfer-encoding",
        "upgrade",
        "proxy-connection",
        "keep-alive"
    )

    private val SAFE_HEADER_NAME_REGEX = Regex("^[A-Za-z0-9_-]{1,64}$")

    private fun isAllowedCustomHeader(name: String): Boolean {
        val lower = name.trim().lowercase(Locale.ROOT)
        if (lower.isEmpty() || lower in BLOCKED_HOP_HEADERS) return false
        return SAFE_HEADER_NAME_REGEX.matches(name.trim())
    }

    private val SENSITIVE_CROSS_HOST_HEADERS = setOf(
        "authorization",
        "cookie"
    )

    private val SENSITIVE_QUERY_REGEX = Regex(
        "(?i)(password|pass|token|auth|key|api_key|access_token|wmsAuthSign|signature)=([^&\\s]+)"
    )
    private val SENSITIVE_PATH_REGEX = Regex(
        "(?i)(/(?:live|movie|series)/[^/]+/)([^/]+)(/)"
    )

    /**
     * Bounded thread-safe in-memory DNS cache (max 64 hosts, 30-min TTL)
     * so channel switches on the same or previously visited IPTV host require 0ms DNS lookup.
     */
    val quantumDns: Dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val key = hostname.lowercase(Locale.ROOT)
            val now = System.currentTimeMillis()
            val cached = dnsCache[key]
            if (cached != null && (now - cached.timestampMs) < DNS_TTL_MS && cached.addresses.isNotEmpty()) {
                return cached.addresses
            }
            val resolved = Dns.SYSTEM.lookup(hostname)
            if (resolved.isNotEmpty()) {
                if (dnsCache.size >= MAX_DNS_ENTRIES) {
                    val oldestKey = dnsCache.entries.minByOrNull { it.value.timestampMs }?.key
                    if (oldestKey != null) dnsCache.remove(oldestKey)
                }
                dnsCache[key] = DnsEntry(resolved, now)
            }
            return resolved
        }
    }

    /**
     * Lightweight in-memory CookieJar scoped strictly per-host so IPTV session cookies set on
     * manifest redirects are preserved between StreamPreFetcher and ExoPlayer's OkHttpDataSource
     * without leaking cookies across unrelated hosts.
     */
    val sessionCookieJar: CookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            if (cookies.isEmpty()) return
            val host = url.host.lowercase(Locale.ROOT)
            if (sessionCookiesByHost.size >= MAX_COOKIE_HOSTS && !sessionCookiesByHost.containsKey(host)) {
                val firstKey = sessionCookiesByHost.keys.firstOrNull()
                if (firstKey != null) sessionCookiesByHost.remove(firstKey)
            }
            val now = System.currentTimeMillis()
            val existing = sessionCookiesByHost[host].orEmpty().filter { it.expiresAt > now }
            val merged = HashMap<String, Cookie>(existing.size + cookies.size)
            for (c in existing) merged[c.name] = c
            for (c in cookies) merged[c.name] = c
            sessionCookiesByHost[host] = merged.values.toList()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val host = url.host.lowercase(Locale.ROOT)
            val list = sessionCookiesByHost[host] ?: return emptyList()
            val now = System.currentTimeMillis()
            return list.filter { it.expiresAt > now && it.matches(url) }
        }
    }

    /**
     * Computes a channel-scoped directory prefix (e.g. `https://cdn.example/live/ch1/`) when the URL
     * has at least 2 path segments or a dedicated leaf directory. Returns null for root-level URLs
     * like `https://cdn.example/ch1.m3u8` so headers NEVER bleed across sibling channels at `/`.
     */
    private fun extractScopedDirectoryPrefix(url: String): String? {
        val parsed = url.toHttpUrlOrNull() ?: return null
        val segments = parsed.pathSegments.filter { it.isNotEmpty() }
        // Require at least 2 segments (e.g. /ch1/index.m3u8 or /live/ch1/master.m3u8)
        // so /ch1.m3u8 and /ch2.m3u8 at root do not collide, and /live/ch1.m3u8 vs /live/ch2.m3u8
        // only share a prefix if they have a deeper channel folder (>=3 segments like /live/ch1/index.m3u8).
        val lastSeg = segments.lastOrNull().orEmpty()
        val hasFileLeaf = lastSeg.contains('.')
        val dirSegments = if (hasFileLeaf) segments.dropLast(1) else segments
        if (dirSegments.isEmpty()) return null
        // Avoid scoping generic shared folders like `/live/` or `/hls/` that host many unrelated channels
        if (dirSegments.size == 1) {
            val single = dirSegments[0].lowercase(Locale.ROOT)
            if (single in setOf("live", "hls", "stream", "streams", "iptv", "tv", "play", "movie", "series")) {
                return null
            }
        }
        val portPart = if ((parsed.scheme == "http" && parsed.port == 80) || (parsed.scheme == "https" && parsed.port == 443)) {
            ""
        } else {
            ":${parsed.port}"
        }
        return "${parsed.scheme}://${parsed.host.lowercase(Locale.ROOT)}$portPart/${dirSegments.joinToString("/")}/"
    }

    private fun canonicalHeaderName(rawKey: String): String {
        return when (rawKey.trim().lowercase(Locale.ROOT)) {
            "user-agent" -> "User-Agent"
            "referer", "referrer" -> "Referer"
            "origin" -> "Origin"
            "authorization" -> "Authorization"
            "cookie" -> "Cookie"
            "x-forwarded-for" -> "X-Forwarded-For"
            "x-requested-with" -> "X-Requested-With"
            "accept" -> "Accept"
            "accept-language" -> "Accept-Language"
            else -> rawKey.trim()
        }
    }

    /**
     * Parses pipe-syntax IPTV URLs (e.g. "https://host/live.m3u8|User-Agent=Custom&Referer=https://...")
     * and optional #EXTVLCOPT/#KODIPROP header maps, registers them with strict channel scoping,
     * and returns the clean stream URL with all signed query parameters preserved verbatim.
     */
    fun extractCleanUrlAndRegisterHeaders(
        rawUrl: String,
        extraHeaders: Map<String, String> = emptyMap()
    ): String {
        val trimmed = rawUrl.trim()
        val pipeIdx = trimmed.indexOf('|')
        val cleanUrl = if (pipeIdx > 0) trimmed.substring(0, pipeIdx).trim() else trimmed
        val merged = LinkedHashMap<String, String>()

        for ((k, v) in extraHeaders) {
            val canonical = canonicalHeaderName(k)
            val cleanVal = v.trim()
            if (isAllowedCustomHeader(canonical) && cleanVal.isNotEmpty()) {
                merged[canonical] = cleanVal
            }
        }

        if (pipeIdx > 0 && pipeIdx < trimmed.lastIndex) {
            val headerPart = trimmed.substring(pipeIdx + 1)
            for (pair in headerPart.split('&', '|')) {
                val eq = pair.indexOf('=')
                if (eq > 0) {
                    val canonical = canonicalHeaderName(pair.substring(0, eq))
                    val rawPart = pair.substring(eq + 1).trim()
                    val rawVal = if (canonical.equals("Cookie", ignoreCase = true) && !rawPart.contains('%')) {
                        rawPart
                    } else {
                        runCatching { URLDecoder.decode(rawPart, "UTF-8") }.getOrElse { rawPart }
                    }
                    if (isAllowedCustomHeader(canonical) && rawVal.isNotEmpty()) {
                        merged[canonical] = rawVal
                    }
                }
            }
        }

        if (merged.isNotEmpty() && cleanUrl.isNotEmpty()) {
            registerStreamHeaders(cleanUrl, merged)
        }
        return cleanUrl
    }

    fun registerStreamHeaders(streamUrl: String, headers: Map<String, String>) {
        if (streamUrl.isBlank() || headers.isEmpty()) return
        val sanitized = LinkedHashMap<String, String>(headers.size)
        for ((k, v) in headers) {
            val canonical = canonicalHeaderName(k)
            val cleanVal = v.trim()
            if (isAllowedCustomHeader(canonical) && cleanVal.isNotEmpty()) {
                sanitized[canonical] = cleanVal
            }
        }
        if (sanitized.isEmpty()) return

        if (customStreamHeaders.size >= MAX_HEADER_ENTRIES) {
            val firstKey = customStreamHeaders.keys.firstOrNull()
            if (firstKey != null) customStreamHeaders.remove(firstKey)
        }
        customStreamHeaders[streamUrl] = sanitized

        val baseNoQuery = streamUrl.substringBefore('?')
        if (baseNoQuery.isNotBlank()) {
            if (baseNoQueryHeaders.size >= MAX_HEADER_ENTRIES) {
                val firstKey = baseNoQueryHeaders.keys.firstOrNull()
                if (firstKey != null) baseNoQueryHeaders.remove(firstKey)
            }
            baseNoQueryHeaders[baseNoQuery] = sanitized
        }

        val dirPrefix = extractScopedDirectoryPrefix(streamUrl)
        if (!dirPrefix.isNullOrBlank()) {
            if (pathPrefixHeaders.size >= MAX_HEADER_ENTRIES) {
                val firstKey = pathPrefixHeaders.keys.firstOrNull()
                if (firstKey != null) pathPrefixHeaders.remove(firstKey)
            }
            pathPrefixHeaders[dirPrefix] = sanitized
        }
    }

    /**
     * Propagates scoped headers across a redirect or HLS variant/segment URL belonging to `sourceUrl`.
     * Protects credentials: `Authorization` and `Cookie` are ONLY forwarded when redirecting to the
     * SAME host, never across unrelated domains.
     */
    fun registerScopedDerivedUrl(sourceUrl: String, derivedUrl: String) {
        if (sourceUrl.isBlank() || derivedUrl.isBlank() || sourceUrl == derivedUrl) return
        val sourceHeaders = headersForUrl(sourceUrl)
        if (sourceHeaders.isEmpty()) return

        val srcHost = sourceUrl.toHttpUrlOrNull()?.host?.lowercase(Locale.ROOT)
        val dstHost = derivedUrl.toHttpUrlOrNull()?.host?.lowercase(Locale.ROOT)
        val sameHost = !srcHost.isNullOrBlank() && srcHost == dstHost

        val filtered = if (sameHost) {
            sourceHeaders
        } else {
            sourceHeaders.filterKeys { it.lowercase(Locale.ROOT) !in SENSITIVE_CROSS_HOST_HEADERS }
        }
        if (filtered.isEmpty()) return

        if (redirectStreamHeaders.size >= MAX_REDIRECT_ENTRIES) {
            val firstKey = redirectStreamHeaders.keys.firstOrNull()
            if (firstKey != null) redirectStreamHeaders.remove(firstKey)
        }
        redirectStreamHeaders[derivedUrl] = filtered

        val derivedPrefix = extractScopedDirectoryPrefix(derivedUrl)
        if (!derivedPrefix.isNullOrBlank() && !pathPrefixHeaders.containsKey(derivedPrefix)) {
            pathPrefixHeaders[derivedPrefix] = filtered
        }
    }

    fun headersForUrl(url: String): Map<String, String> {
        if (url.isBlank()) return emptyMap()
        // 1. Exact URL match
        customStreamHeaders[url]?.let { return it }
        // 2. Explicit redirect / variant match
        redirectStreamHeaders[url]?.let { return it }
        // 3. Exact base URL without query token
        val baseNoQuery = url.substringBefore('?')
        baseNoQueryHeaders[baseNoQuery]?.let { return it }
        // 4. Scoped channel directory prefix match (longest matching prefix wins, never host-wide)
        var bestPrefixLen = 0
        var bestHeaders: Map<String, String>? = null
        for ((prefix, hdrs) in pathPrefixHeaders) {
            if (baseNoQuery.startsWith(prefix, ignoreCase = true) && prefix.length > bestPrefixLen) {
                bestPrefixLen = prefix.length
                bestHeaders = hdrs
            }
        }
        return bestHeaders ?: emptyMap()
    }

    fun registerStreamDrmConfig(streamUrl: String, config: StreamDrmConfig) {
        if (streamUrl.isBlank() || config.isEmpty()) return
        if (streamDrmConfigs.size >= MAX_DRM_ENTRIES) {
            val firstKey = streamDrmConfigs.keys.firstOrNull()
            if (firstKey != null) streamDrmConfigs.remove(firstKey)
        }
        streamDrmConfigs[streamUrl] = config
        val baseNoQuery = streamUrl.substringBefore('?')
        if (baseNoQuery.isNotBlank()) {
            if (baseNoQueryDrmConfigs.size >= MAX_DRM_ENTRIES) {
                val firstKey = baseNoQueryDrmConfigs.keys.firstOrNull()
                if (firstKey != null) baseNoQueryDrmConfigs.remove(firstKey)
            }
            baseNoQueryDrmConfigs[baseNoQuery] = config
        }
    }

    fun drmConfigForUrl(streamUrl: String?): StreamDrmConfig? {
        if (streamUrl.isNullOrBlank()) return null
        streamDrmConfigs[streamUrl]?.let { return it }
        val baseNoQuery = streamUrl.substringBefore('?')
        if (baseNoQuery.isNotBlank()) {
            baseNoQueryDrmConfigs[baseNoQuery]?.let { return it }
        }
        return null
    }

    private val B64URL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    private fun encodeBase64UrlNoPad(bytes: ByteArray): String {
        val out = StringBuilder((bytes.size * 4 + 2) / 3)
        var i = 0
        while (i < bytes.size) {
            val b0 = bytes[i].toInt() and 0xFF
            val hasB1 = i + 1 < bytes.size
            val hasB2 = i + 2 < bytes.size
            val b1 = if (hasB1) bytes[i + 1].toInt() and 0xFF else 0
            val b2 = if (hasB2) bytes[i + 2].toInt() and 0xFF else 0
            val triple = (b0 shl 16) or (b1 shl 8) or b2
            out.append(B64URL_ALPHABET[(triple shr 18) and 0x3F])
            out.append(B64URL_ALPHABET[(triple shr 12) and 0x3F])
            if (hasB1) out.append(B64URL_ALPHABET[(triple shr 6) and 0x3F])
            if (hasB2) out.append(B64URL_ALPHABET[triple and 0x3F])
            i += 3
        }
        return out.toString()
    }

    private fun hexToBytesOrNull(hexRaw: String): ByteArray? {
        val clean = hexRaw.trim().replace("-", "").replace(" ", "")
        if (clean.length < 2 || clean.length % 2 != 0) return null
        val out = ByteArray(clean.length / 2)
        for (i in out.indices) {
            val hi = Character.digit(clean[i * 2], 16)
            val lo = Character.digit(clean[i * 2 + 1], 16)
            if (hi < 0 || lo < 0) return null
            out[i] = ((hi shl 4) or lo).toByte()
        }
        return out
    }

    /**
     * Converts OTT Navigator / Kodi ClearKey `license_key` values into a valid W3C ClearKey JWK JSON payload.
     * Supports:
     * - Already-formatted JWK JSON: `{"keys":[{"kty":"oct","k":"...","kid":"..."}],"type":"temporary"}`
     * - Single or comma-separated hex `KID:KEY` pairs: `0123...abcd:fedc...3210`
     * - Returns null if `rawLicenseKey` is an HTTP(S) license server URL (handled via HttpMediaDrmCallback).
     */
    fun buildClearKeyJwkJson(rawLicenseKey: String): String? {
        val trimmed = rawLicenseKey.trim()
        if (trimmed.isEmpty()) return null
        if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            return null
        }
        if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
            return trimmed
        }
        val keysArr = JSONArray()
        for (token in trimmed.split(',', ';', '\n')) {
            val part = token.trim()
            val colon = part.indexOf(':')
            if (colon <= 0 || colon >= part.lastIndex) continue
            val kidHex = part.substring(0, colon).trim()
            val keyHex = part.substring(colon + 1).trim()
            val kidBytes = hexToBytesOrNull(kidHex)
            val keyBytes = hexToBytesOrNull(keyHex)
            val kidB64 = if (kidBytes != null) encodeBase64UrlNoPad(kidBytes) else kidHex.trimEnd('=')
            val keyB64 = if (keyBytes != null) encodeBase64UrlNoPad(keyBytes) else keyHex.trimEnd('=')
            if (kidB64.isNotEmpty() && keyB64.isNotEmpty()) {
                keysArr.put(
                    JSONObject()
                        .put("kty", "oct")
                        .put("kid", kidB64)
                        .put("k", keyB64)
                )
            }
        }
        if (keysArr.length() == 0) return null
        return JSONObject()
            .put("keys", keysArr)
            .put("type", "temporary")
            .toString()
    }

    fun saveStreamMetadataCache(cacheDir: File) {
        runCatching {
            val root = JSONObject()
            val hdrObj = JSONObject()
            var hCount = 0
            for ((url, map) in customStreamHeaders) {
                if (hCount >= 4000) break
                val mObj = JSONObject()
                for ((k, v) in map) mObj.put(k, v)
                hdrObj.put(url, mObj)
                hCount++
            }
            val drmObj = JSONObject()
            var dCount = 0
            for ((url, cfg) in streamDrmConfigs) {
                if (dCount >= 4000) break
                drmObj.put(
                    url,
                    JSONObject()
                        .put("lt", cfg.licenseType)
                        .put("lk", cfg.licenseKey)
                        .put("mt", cfg.manifestType)
                )
                dCount++
            }
            root.put("headers", hdrObj)
            root.put("drm", drmObj)
            val outFile = File(cacheDir, "ram_player_stream_meta_v21.json")
            outFile.writeText(root.toString(), Charsets.UTF_8)
        }
    }

    fun loadStreamMetadataCache(cacheDir: File) {
        runCatching {
            val inFile = File(cacheDir, "ram_player_stream_meta_v21.json")
            if (!inFile.isFile || inFile.length() <= 2L) return
            val root = JSONObject(inFile.readText(Charsets.UTF_8))
            val hdrObj = root.optJSONObject("headers")
            if (hdrObj != null) {
                val keys = hdrObj.keys()
                while (keys.hasNext()) {
                    val url = keys.next()
                    val mObj = hdrObj.optJSONObject(url) ?: continue
                    val map = LinkedHashMap<String, String>()
                    val mKeys = mObj.keys()
                    while (mKeys.hasNext()) {
                        val hk = mKeys.next()
                        val hv = mObj.optString(hk, "")
                        if (hv.isNotEmpty()) map[hk] = hv
                    }
                    if (map.isNotEmpty()) registerStreamHeaders(url, map)
                }
            }
            val drmObj = root.optJSONObject("drm")
            if (drmObj != null) {
                val keys = drmObj.keys()
                while (keys.hasNext()) {
                    val url = keys.next()
                    val d = drmObj.optJSONObject(url) ?: continue
                    registerStreamDrmConfig(
                        url,
                        StreamDrmConfig(
                            licenseType = d.optString("lt", ""),
                            licenseKey = d.optString("lk", ""),
                            manifestType = d.optString("mt", "")
                        )
                    )
                }
            }
        }
    }

    /**
     * Transparently decompresses GZIP-encoded M3U/XMLTV playlists (e.g. `.m3u.gz` or raw gzip bytes
     * with magic header `0x1F 0x8B`), falling back to the raw stream for plain UTF-8 playlists.
     */
    fun openDecompressedStream(rawStream: InputStream): InputStream {
        val pb = PushbackInputStream(rawStream, 2)
        val header = ByteArray(2)
        val read = pb.read(header)
        if (read > 0) {
            pb.unread(header, 0, read)
        }
        return if (read == 2 && (header[0].toInt() and 0xFF) == 0x1F && (header[1].toInt() and 0xFF) == 0x8B) {
            GZIPInputStream(pb)
        } else {
            pb
        }
    }

    fun clearStreamHeaders() {
        customStreamHeaders.clear()
        baseNoQueryHeaders.clear()
        pathPrefixHeaders.clear()
        redirectStreamHeaders.clear()
        streamDrmConfigs.clear()
        baseNoQueryDrmConfigs.clear()
    }

    /**
     * Redacts passwords, tokens, and Xtream /live|movie|series/<user>/<pass>/ path segments so sensitive
     * credentials are never written to Logcat or exposed in UI error strings.
     */
    fun redactSensitiveUrl(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var masked = raw.replace(SENSITIVE_QUERY_REGEX, "$1=****")
        masked = masked.replace(SENSITIVE_PATH_REGEX, "$1****$3")
        return masked
    }

    private val streamHeaderInterceptor = Interceptor { chain ->
        val original = chain.request()
        val urlStr = original.url.toString()
        val host = original.url.host
        val custom = headersForUrl(urlStr)
        val explicitCustomUa = custom.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value

        fun buildRequestWithUa(ua: String) = original.newBuilder().apply {
            header("User-Agent", ua)
            if (original.header("Accept").isNullOrBlank() && custom.keys.none { it.equals("Accept", ignoreCase = true) }) {
                header("Accept", "*/*")
            }
            for ((k, v) in custom) {
                if (original.header(k).isNullOrBlank() || k.equals("User-Agent", ignoreCase = true)) {
                    header(k, v)
                }
            }
        }.build()

        // If channel explicitly specifies a custom User-Agent (e.g. #EXTVLCOPT / pipe), honor it strictly
        if (!explicitCustomUa.isNullOrBlank()) {
            val response = chain.proceed(buildRequestWithUa(explicitCustomUa))
            val finalUrl = response.request.url.toString()
            if (finalUrl != urlStr && custom.isNotEmpty()) {
                registerScopedDerivedUrl(urlStr, finalUrl)
            }
            return@Interceptor response
        }

        val uaChain = buildUserAgentFallbackChain(host)
        var lastResponse = chain.proceed(buildRequestWithUa(uaChain.first()))
        if (lastResponse.isSuccessful) {
            recordWinningUserAgent(host, uaChain.first())
        } else if (isUserAgentFallbackHttpCode(lastResponse.code) && uaChain.size > 1) {
            for (i in 1 until uaChain.size) {
                val candidateUa = uaChain[i]
                runCatching { lastResponse.close() }
                val retryResp = chain.proceed(buildRequestWithUa(candidateUa))
                lastResponse = retryResp
                if (retryResp.isSuccessful) {
                    recordWinningUserAgent(host, candidateUa)
                    break
                }
                if (!isUserAgentFallbackHttpCode(retryResp.code)) {
                    break
                }
            }
        }

        val finalUrl = lastResponse.request.url.toString()
        if (finalUrl != urlStr && custom.isNotEmpty()) {
            registerScopedDerivedUrl(urlStr, finalUrl)
        }
        lastResponse
    }

    private val apiUserAgentInterceptor = Interceptor { chain ->
        val original = chain.request()
        val host = original.url.host
        val existingUa = original.header("User-Agent")
        val shouldManageUa = existingUa.isNullOrBlank() || existingUa == DEFAULT_USER_AGENT
        if (!shouldManageUa) {
            return@Interceptor chain.proceed(original)
        }
        val uaChain = buildUserAgentFallbackChain(host)
        var lastResponse = chain.proceed(original.newBuilder().header("User-Agent", uaChain.first()).build())
        if (lastResponse.isSuccessful) {
            recordWinningUserAgent(host, uaChain.first())
        } else if (isUserAgentFallbackHttpCode(lastResponse.code) && uaChain.size > 1) {
            for (i in 1 until uaChain.size) {
                val candidateUa = uaChain[i]
                runCatching { lastResponse.close() }
                val retryResp = chain.proceed(original.newBuilder().header("User-Agent", candidateUa).build())
                lastResponse = retryResp
                if (retryResp.isSuccessful) {
                    recordWinningUserAgent(host, candidateUa)
                    break
                }
                if (!isUserAgentFallbackHttpCode(retryResp.code)) {
                    break
                }
            }
        }
        lastResponse
    }

    fun prewarmHostDns(streamUrl: String?) {
        if (streamUrl.isNullOrBlank()) return
        runCatching {
            val host = streamUrl.toHttpUrlOrNull()?.host ?: return
            quantumDns.lookup(host)
        }
    }

    fun cancelCallsWithTag(tag: Any) {
        runCatching {
            for (client in listOf(fastMetaClient, apiClient)) {
                for (call in client.dispatcher.queuedCalls()) {
                    if (call.request().tag() == tag) call.cancel()
                }
                for (call in client.dispatcher.runningCalls()) {
                    if (call.request().tag() == tag) call.cancel()
                }
            }
        }
    }

    fun evictIdleConnections() {
        runCatching {
            metadataPool.evictAll()
            apiPool.evictAll()
        }
    }

    private fun dispatcher(max: Int, perHost: Int) = Dispatcher().apply {
        maxRequests = max
        maxRequestsPerHost = perHost
    }

    private fun pool(maxIdle: Int) = ConnectionPool(maxIdle, 5, TimeUnit.MINUTES)

    private val metadataDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val apiDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val streamDispatcher by lazy { dispatcher(max = 16, perHost = 8) }

    private val metadataPool by lazy { pool(maxIdle = 4) }
    private val apiPool by lazy { pool(maxIdle = 6) }
    private val streamPool by lazy { pool(maxIdle = 12) }

    /** Short, bounded calls for connection checks, pre-fetch warmup and lightweight metadata. */
    val fastMetaClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .addInterceptor(apiUserAgentInterceptor)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(metadataPool)
            .dispatcher(metadataDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Longer timeouts for M3U, Xtream and XMLTV responses. */
    val apiClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .addInterceptor(apiUserAgentInterceptor)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(apiPool)
            .dispatcher(apiDispatcher)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Dedicated live-stream dispatcher with 0ms cached DNS, scoped headers, session CookieJar & 5-min keep-alive pool. */
    val streamClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .addInterceptor(streamHeaderInterceptor)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(streamPool)
            .dispatcher(streamDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
}
